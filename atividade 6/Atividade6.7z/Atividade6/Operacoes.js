var num1 = parseInt(prompt("Informe o Primeiro Numero: "));
var num2 = parseInt(prompt("Informe o Segundo Numero"));

const soma = num1 + num2;
const subtracao = num1 - num2;
const multiplicacao = num1 * num2;
const divisao = num1 / num2;
const restoDiv= num1 % num2;

alert("A soma entre os numeros é: "+soma);
alert("a subtração dos numeros é: "+subtracao);
alert("o produto dos dois numeros é: "+multiplicacao);
alert("a divisão entre os numeros é: "+divisao);
alert("o resto da divisão dos numeros é: "+restoDiv);