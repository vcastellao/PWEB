

var nome = prompt("Informe o Nome do aluno");
const notas = [];
notas[0] = parseInt(prompt("Informe a Primeira nota:"));
notas[1] = parseInt(prompt("Informe a Segunda nota"));
notas[2] = parseInt(prompt("Informe a Terceira nota"));
notas[3] = parseInt(prompt("Informe a Quarta nota"));
alert("As notas são: "+notas[0]+" "+notas[1]+" "+notas[2]+" "+notas[3]);
var media = (notas [0] + notas [1] + notas [2] + notas [3]) / 4;
alert("A media do aluno: "+nome+" é: "+media);