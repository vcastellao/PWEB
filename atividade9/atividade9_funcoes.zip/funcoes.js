// 1) Maior de três números
function maiorNumero(a, b, c) {
  return Math.max(a, b, c);
}

function mostrarMaior() {
  const n1 = Number(document.getElementById("num1").value);
  const n2 = Number(document.getElementById("num2").value);
  const n3 = Number(document.getElementById("num3").value);

  const resultado = maiorNumero(n1, n2, n3);
  document.getElementById("resultado1").innerText = `Maior número: ${resultado}`;
}

// 2) Números em ordem crescente
function ordenarNumeros(a, b, c) {
  return [a, b, c].sort((x, y) => x - y);
}

function mostrarOrdem() {
  const n1 = Number(document.getElementById("ord1").value);
  const n2 = Number(document.getElementById("ord2").value);
  const n3 = Number(document.getElementById("ord3").value);

  const resultado = ordenarNumeros(n1, n2, n3);
  document.getElementById("resultado2").innerText = `Ordem crescente: ${resultado.join(", ")}`;
}

// 3) Verificar se é palíndromo
function ehPalindromo(texto) {
  const txt = texto.toUpperCase().replace(/\s+/g, '');
  const invertido = txt.split('').reverse().join('');
  return txt === invertido;
}

function verificarPalindromo() {
  const texto = document.getElementById("texto").value;
  const resultado = ehPalindromo(texto);
  document.getElementById("resultado3").innerText = resultado 
    ? "É um palíndromo!" 
    : "Não é um palíndromo.";
}

// 4) Verificar tipo de triângulo
function tipoTriangulo(a, b, c) {
  if (a + b <= c || a + c <= b || b + c <= a) {
    return "Os valores não formam um triângulo.";
  }
  if (a === b && b === c) return "Triângulo equilátero";
  if (a === b || a === c || b === c) return "Triângulo isósceles";
  return "Triângulo escaleno";
}

function verificarTriangulo() {
  const l1 = Number(document.getElementById("lado1").value);
  const l2 = Number(document.getElementById("lado2").value);
  const l3 = Number(document.getElementById("lado3").value);

  const resultado = tipoTriangulo(l1, l2, l3);
  document.getElementById("resultado4").innerText = resultado;
}
