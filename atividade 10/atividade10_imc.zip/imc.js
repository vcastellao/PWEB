function calcularIMC(peso, altura) {
  return peso / (altura * altura);
}

function classificarIMC(imc) {
  if (imc < 18.5) return "Magreza (Obesidade Grau 0)";
  if (imc < 25) return "Normal (Obesidade Grau 0)";
  if (imc < 30) return "Sobrepeso (Obesidade Grau I)";
  if (imc < 40) return "Obesidade (Grau II)";
  return "Obesidade Grave (Grau III)";
}

function calcular() {
  const peso = Number(document.getElementById("peso").value);
  const altura = Number(document.getElementById("altura").value);
  const resultado = document.getElementById("resultado");

  if (!peso || !altura || peso <= 0 || altura <= 0) {
    resultado.innerText = "Por favor, insira valores válidos.";
    return;
  }

  const imc = calcularIMC(peso, altura);
  const classificacao = classificarIMC(imc);

  resultado.innerText = `Seu IMC é ${imc.toFixed(2)} — ${classificacao}`;
}
